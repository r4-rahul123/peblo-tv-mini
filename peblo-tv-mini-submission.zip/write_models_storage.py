﻿import os
from pathlib import Path

def write_file(rel_path, content):
    full_path = Path("backend") / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {full_path}")

# Models: app/models/models.py
write_file("app/models/__init__.py", """
from app.models.models import Show, Season, Episode, Artwork, PublishRun
""")

write_file("app/models/models.py", """
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, Boolean, Text, ForeignKey, DateTime, UniqueConstraint, Float
from sqlalchemy.orm import relationship
from app.core.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class Show(Base):
    __tablename__ = "shows"

    id = Column(String(64), primary_key=True, default=generate_uuid, index=True)
    title = Column(String(255), nullable=False, index=True)
    synopsis = Column(Text, nullable=True)
    section = Column(String(100), nullable=True, index=True)
    category = Column(String(100), nullable=True, index=True)
    target_age_group = Column(String(50), nullable=True)
    is_featured = Column(Boolean, default=False)
    status = Column(String(50), default="draft") # draft, published, archived
    poster_url = Column(String(500), nullable=True)
    banner_url = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    seasons = relationship("Season", back_populates="show", cascade="all, delete-orphan", order_by="Season.season_number")

class Season(Base):
    __tablename__ = "seasons"

    id = Column(String(64), primary_key=True, default=generate_uuid, index=True)
    show_id = Column(String(64), ForeignKey("shows.id", ondelete="CASCADE"), nullable=False, index=True)
    season_number = Column(Integer, nullable=False, default=1) # 0 is reserved for Trailers per spec
    title = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("show_id", "season_number", name="uq_show_season_number"),
    )

    show = relationship("Show", back_populates="seasons")
    episodes = relationship("Episode", back_populates="season", cascade="all, delete-orphan", order_by="Episode.episode_number")

class Episode(Base):
    __tablename__ = "episodes"

    id = Column(String(64), primary_key=True, default=generate_uuid, index=True)
    season_id = Column(String(64), ForeignKey("seasons.id", ondelete="CASCADE"), nullable=False, index=True)
    episode_number = Column(Integer, nullable=False)
    title = Column(String(255), nullable=False, index=True)
    synopsis = Column(Text, nullable=True)
    duration_seconds = Column(Integer, default=0)
    content_group = Column(String(100), nullable=False, index=True) # group ID for language variants
    language = Column(String(20), nullable=False, index=True) # 'en', 'hi', etc.
    video_url = Column(String(500), nullable=True)
    thumbnail_url = Column(String(500), nullable=True)
    status = Column(String(50), default="draft") # draft, published
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("content_group", "language", name="uq_content_group_language"),
    )

    season = relationship("Season", back_populates="episodes")

class Artwork(Base):
    __tablename__ = "artworks"

    id = Column(String(64), primary_key=True, default=generate_uuid, index=True)
    artwork_type = Column(String(50), nullable=False) # poster, banner, thumbnail
    file_name = Column(String(255), nullable=False)
    file_url = Column(String(500), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    width = Column(Integer, nullable=False)
    height = Column(Integer, nullable=False)
    aspect_ratio = Column(Float, nullable=False)
    content_type = Column(String(100), nullable=False)
    uploaded_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class PublishRun(Base):
    __tablename__ = "publish_runs"

    id = Column(String(64), primary_key=True, default=generate_uuid, index=True)
    run_id = Column(String(100), nullable=False, unique=True, index=True)
    triggered_by = Column(String(100), nullable=False) # e.g. "admin@mypeblo.com"
    status = Column(String(50), nullable=False) # SUCCESS, FAILED, BLOCKED
    shows_count = Column(Integer, default=0)
    episodes_count = Column(Integer, default=0)
    sections_count = Column(Integer, default=0)
    catalogue_size_bytes = Column(Integer, default=0)
    catalogue_path = Column(String(500), nullable=True)
    error_message = Column(Text, nullable=True)
    validation_snapshot = Column(Text, nullable=True) # JSON snapshot of validation issues if any
    created_at = Column(DateTime, default=datetime.utcnow)
""")

# Storage abstractions: app/services/storage/
write_file("app/services/storage/__init__.py", """
from app.services.storage.base import StorageProvider
from app.services.storage.local import LocalDiskStorageProvider
from app.services.storage.r2 import CloudflareR2StorageProvider
from app.core.config import settings

def get_storage_provider() -> StorageProvider:
    if settings.STORAGE_BACKEND == "r2" and settings.R2_ACCESS_KEY_ID:
        return CloudflareR2StorageProvider()
    return LocalDiskStorageProvider(base_dir=settings.LOCAL_STORAGE_DIR)
""")

write_file("app/services/storage/base.py", """
from abc import ABC, abstractmethod
from typing import BinaryIO, Optional, Union

class StorageProvider(ABC):
    @abstractmethod
    async def save_file(self, file_content: bytes, destination_path: str, content_type: str = "image/jpeg") -> str:
        \"\"\"Save a file and return its accessible URL or path.\"\"\"
        pass

    @abstractmethod
    async def read_file(self, path: str) -> bytes:
        \"\"\"Read raw content of a stored file.\"\"\"
        pass

    @abstractmethod
    async def atomic_write(self, content: Union[str, bytes], destination_path: str) -> str:
        \"\"\"
        Atomically write content to destination_path so that readers never observe
        a partial or corrupt state.
        \"\"\"
        pass

    @abstractmethod
    async def file_exists(self, path: str) -> bool:
        \"\"\"Check if a file exists.\"\"\"
        pass
""")

write_file("app/services/storage/local.py", """
import os
import shutil
import aiofiles
from pathlib import Path
from typing import Union
from app.services.storage.base import StorageProvider

class LocalDiskStorageProvider(StorageProvider):
    def __init__(self, base_dir: str = "./storage"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        (self.base_dir / "artwork").mkdir(parents=True, exist_ok=True)
        (self.base_dir / "catalog").mkdir(parents=True, exist_ok=True)

    async def save_file(self, file_content: bytes, destination_path: str, content_type: str = "image/jpeg") -> str:
        # Normalize relative path
        clean_path = destination_path.lstrip("/").replace("storage/", "")
        target_path = self.base_dir / clean_path
        target_path.parent.mkdir(parents=True, exist_ok=True)

        async with aiofiles.open(target_path, "wb") as f:
            await f.write(file_content)

        return f"/storage/{clean_path}".replace("\\\\", "/")

    async def read_file(self, path: str) -> bytes:
        clean_path = path.lstrip("/").replace("storage/", "")
        target_path = self.base_dir / clean_path
        if not target_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        async with aiofiles.open(target_path, "rb") as f:
            return await f.read()

    async def atomic_write(self, content: Union[str, bytes], destination_path: str) -> str:
        \"\"\"
        Atomic write implementation:
        1. Write content to a temporary staging file (destination_path.tmp.<pid>)
        2. Flush and sync to disk
        3. Use os.replace() which performs an atomic rename/swap on POSIX and modern Windows NTFS.
        \"\"\"
        clean_path = destination_path.lstrip("/").replace("storage/", "")
        target_path = self.base_dir / clean_path
        target_path.parent.mkdir(parents=True, exist_ok=True)

        tmp_path = target_path.with_suffix(f".tmp.{os.getpid()}")

        if isinstance(content, str):
            data = content.encode("utf-8")
        else:
            data = content

        async with aiofiles.open(tmp_path, "wb") as f:
            await f.write(data)
            await f.flush()

        # Atomic rename swap
        os.replace(tmp_path, target_path)

        return f"/storage/{clean_path}".replace("\\\\", "/")

    async def file_exists(self, path: str) -> bool:
        clean_path = path.lstrip("/").replace("storage/", "")
        target_path = self.base_dir / clean_path
        return target_path.exists()
""")

write_file("app/services/storage/r2.py", """
import io
import boto3
from botocore.exceptions import ClientError
from typing import Union
from app.services.storage.base import StorageProvider
from app.core.config import settings

class CloudflareR2StorageProvider(StorageProvider):
    \"\"\"
    Production-grade Cloudflare R2 / S3 storage abstraction.
    R2 is S3-compatible, so we use boto3 configured for Cloudflare R2 endpoints.
    Atomic writes are inherent in S3/R2 PUT operations (object uploads are atomic).
    \"\"\"
    def __init__(self):
        self.endpoint_url = f"https://{settings.R2_ACCOUNT_ID}.r2.cloudflarestorage.com"
        self.bucket_name = settings.R2_BUCKET_NAME
        self.public_url = settings.R2_PUBLIC_URL or f"https://pub-{settings.R2_ACCOUNT_ID}.r2.dev"
        self.client = boto3.client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=settings.R2_ACCESS_KEY_ID,
            aws_secret_access_key=settings.R2_SECRET_ACCESS_KEY,
            region_name="auto"
        )

    async def save_file(self, file_content: bytes, destination_path: str, content_type: str = "image/jpeg") -> str:
        clean_key = destination_path.lstrip("/").replace("storage/", "")
        self.client.put_object(
            Bucket=self.bucket_name,
            Key=clean_key,
            Body=file_content,
            ContentType=content_type
        )
        return f"{self.public_url}/{clean_key}"

    async def read_file(self, path: str) -> bytes:
        clean_key = path.lstrip("/").replace("storage/", "")
        try:
            response = self.client.get_object(Bucket=self.bucket_name, Key=clean_key)
            return response["Body"].read()
        except ClientError as e:
            raise FileNotFoundError(f"R2 Object {path} not found: {e}")

    async def atomic_write(self, content: Union[str, bytes], destination_path: str) -> str:
        clean_key = destination_path.lstrip("/").replace("storage/", "")
        data = content.encode("utf-8") if isinstance(content, str) else content
        # S3 PUT is fundamentally atomic
        self.client.put_object(
            Bucket=self.bucket_name,
            Key=clean_key,
            Body=data,
            ContentType="application/json"
        )
        return f"{self.public_url}/{clean_key}"

    async def file_exists(self, path: str) -> bool:
        clean_key = path.lstrip("/").replace("storage/", "")
        try:
            self.client.head_object(Bucket=self.bucket_name, Key=clean_key)
            return True
        except ClientError:
            return False
""")

print("Models and Storage Providers written.")
