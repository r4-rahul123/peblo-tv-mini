﻿import os
from pathlib import Path

def write_file(rel_path, content):
    full_path = Path("backend") / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {full_path}")

# 1. requirements.txt
write_file("requirements.txt", """
fastapi==0.110.0
uvicorn[standard]==0.28.0
pydantic==2.6.4
pydantic-settings==2.2.1
sqlalchemy==2.0.28
asyncpg==0.29.0
aiosqlite==0.20.0
alembic==1.13.1
pillow==10.2.0
python-multipart==0.0.9
python-jose[cryptography]==3.3.0
boto3==1.34.69
aiofiles==23.2.1
pytest==8.1.1
pytest-asyncio==0.23.6
httpx==0.27.0
""")

# 2. app/core/config.py
write_file("app/core/config.py", """
from typing import List, Optional
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    PROJECT_NAME: str = "Peblo TV Mini API"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = "supersecret_peblo_tv_mini_dev_key_change_in_prod"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 # 1 day

    # Database
    DATABASE_URL: str = "sqlite+aiosqlite:///./peblo.db" # Default fallback, postgres in docker
    
    # Storage
    STORAGE_BACKEND: str = "local" # "local" or "r2"
    LOCAL_STORAGE_DIR: str = "./storage"
    
    # R2 / S3 configuration (swappable storage abstraction)
    R2_ACCOUNT_ID: Optional[str] = None
    R2_ACCESS_KEY_ID: Optional[str] = None
    R2_SECRET_ACCESS_KEY: Optional[str] = None
    R2_BUCKET_NAME: Optional[str] = "peblo-tv-mini-catalogue"
    R2_PUBLIC_URL: Optional[str] = None
    
    # CORS
    BACKEND_CORS_ORIGINS: List[str] = ["*"]

    class Config:
        case_sensitive = True
        env_file = ".env"

settings = Settings()
""")

# 3. app/core/database.py
write_file("app/core/database.py", """
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import declarative_base
from app.core.config import settings

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=False,
    future=True,
    pool_pre_ping=True
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)

Base = declarative_base()

async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()
""")

# 4. app/core/security.py
write_file("app/core/security.py", """
from datetime import datetime, timedelta
from typing import Optional, Any
from jose import jwt
from app.core.config import settings

def create_access_token(subject: str, role: str, expires_delta: Optional[timedelta] = None) -> str:
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {"exp": expire, "sub": str(subject), "role": role}
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

def verify_token(token: str) -> Optional[dict]:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except Exception:
        return None
""")

print("Core backend files written.")
