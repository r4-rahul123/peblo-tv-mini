﻿import os
from pathlib import Path

def write_file(rel_path, content):
    full_path = Path("cms-ui") / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {full_path}")

# package.json
write_file("package.json", """
{
  "name": "peblo-tv-cms",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "@tanstack/react-query": "^5.28.4",
    "axios": "^1.6.8",
    "clsx": "^2.1.0",
    "lucide-react": "^0.358.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "tailwind-merge": "^2.2.1"
  },
  "devDependencies": {
    "@types/react": "^18.2.66",
    "@types/react-dom": "^18.2.22",
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer": "^10.4.19",
    "postcss": "^8.4.38",
    "tailwindcss": "^3.4.1",
    "typescript": "^5.2.2",
    "vite": "^5.1.6"
  }
}
""")

# tsconfig.json
write_file("tsconfig.json", """
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": false,
    "noUnusedLocals": false,
    "noUnusedParameters": false,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["src"]
}
""")

# vite.config.ts
write_file("vite.config.ts", """
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3001,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
      '/admin': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
      '/storage': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
      '/catalog': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      }
    }
  }
});
""")

# tailwind.config.js
write_file("tailwind.config.js", """
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        peblo: {
          blue: "#1E88E5",
          dark: "#0F172A",
          accent: "#FF9800",
          card: "#1E293B",
          border: "#334155"
        }
      }
    },
  },
  plugins: [],
}
""")

# postcss.config.js
write_file("postcss.config.js", """
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
""")

# index.html
write_file("index.html", """
<!doctype html>
<html lang="en" class="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Peblo TV — Content Studio CMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  </head>
  <body class="bg-slate-950 text-slate-100 font-['Plus_Jakarta_Sans',sans-serif] min-h-screen">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
""")

# src/types.ts
write_file("src/types.ts", """
export interface Episode {
  id: string;
  season_id: string;
  episode_number: number;
  title: string;
  synopsis?: string;
  duration_seconds: number;
  content_group: string;
  language: string;
  video_url?: string;
  thumbnail_url?: string;
  status: 'draft' | 'published';
  created_at: string;
  updated_at: string;
}

export interface Season {
  id: string;
  show_id: string;
  season_number: number;
  title?: string;
  created_at: string;
  episodes: Episode[];
}

export interface Show {
  id: string;
  title: string;
  synopsis?: string;
  section?: string;
  category?: string;
  target_age_group?: string;
  is_featured: boolean;
  status: 'draft' | 'published';
  poster_url?: string;
  banner_url?: string;
  created_at: string;
  updated_at: string;
  seasons: Season[];
}

export interface ValidationIssue {
  entity_type: string;
  entity_id: string;
  entity_title: string;
  severity: 'BLOCKER' | 'WARNING';
  field: string;
  message: string;
  action_required: string;
}

export interface ValidationReport {
  is_publishable: boolean;
  total_blockers: number;
  total_warnings: number;
  published_shows_count: number;
  published_episodes_count: number;
  issues_by_show: Record<string, ValidationIssue[]>;
  general_issues: ValidationIssue[];
}

export interface PublishRun {
  run_id: string;
  triggered_by: string;
  status: string;
  shows_count: number;
  episodes_count: number;
  sections_count: number;
  catalogue_path?: string;
  error_message?: string;
  created_at: string;
}

export interface ArtworkUploadResponse {
  id: string;
  artwork_type: string;
  file_name: string;
  file_url: string;
  width: number;
  height: number;
  aspect_ratio: number;
  file_size_bytes: number;
}
""")

print("CMS base setup files created.")
