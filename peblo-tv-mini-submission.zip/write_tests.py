﻿import os
from pathlib import Path

def write_file(rel_path, content):
    full_path = Path("backend") / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {full_path}")

# 1. test_artwork.py
write_file("tests/test_artwork.py", """
import os
import io
import pytest
from PIL import Image
from app.services.artwork_validator import validate_artwork_image

def create_image_bytes(width, height, format="JPEG", quality=85):
    img = Image.new("RGB", (width, height), color=(50, 100, 150))
    buf = io.BytesIO()
    img.save(buf, format=format, quality=quality)
    return buf.getvalue()

def test_valid_poster_artwork():
    # 2:3 ratio (~600x900)
    data = create_image_bytes(600, 900)
    res = validate_artwork_image(data, "poster")
    assert res.is_valid is True
    assert len(res.errors) == 0
    assert res.width == 600
    assert res.height == 900

def test_valid_banner_artwork():
    # 16:9 ratio (~1280x720)
    data = create_image_bytes(1280, 720)
    res = validate_artwork_image(data, "banner")
    assert res.is_valid is True
    assert len(res.errors) == 0

def test_valid_thumbnail_artwork():
    # 16:9 ratio (~640x360)
    data = create_image_bytes(640, 360)
    res = validate_artwork_image(data, "thumbnail")
    assert res.is_valid is True

def test_reject_wrong_aspect_ratio():
    # 1:1 square for poster (expected 2:3)
    data = create_image_bytes(600, 600)
    res = validate_artwork_image(data, "poster")
    assert res.is_valid is False
    assert any("Invalid aspect ratio" in err for err in res.errors)

def test_reject_too_small_resolution():
    # 100x100 is below minimum dimension floor
    data = create_image_bytes(100, 100)
    res = validate_artwork_image(data, "thumbnail")
    assert res.is_valid is False
    assert any("Resolution is too low" in err for err in res.errors)

def test_reject_oversized_file():
    # Create large byte array exceeding 200KB limit
    oversized_data = b"0" * (250 * 1024)
    res = validate_artwork_image(oversized_data, "banner")
    assert res.is_valid is False
    assert any("exceeds the maximum allowed limit of 200 KB" in err for err in res.errors)
""")

# 2. test_publisher.py
write_file("tests/test_publisher.py", """
import json
import pytest
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from app.core.database import Base
from app.models.models import Show, Season, Episode
from app.services.catalog_publisher import publish_catalog
from app.services.storage.local import LocalDiskStorageProvider

@pytest.fixture
async def test_db():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as session:
        yield session
    await engine.dispose()

@pytest.mark.asyncio
async def test_catalog_content_group_collapsing(test_db):
    # Setup a valid show with Hindi and English episodes sharing same content_group
    show = Show(
        id="test-show-1",
        title="Bilingual Moti",
        section="Top Picks for You",
        status="published",
        poster_url="/storage/artwork/poster.jpg",
        banner_url="/storage/artwork/banner.jpg"
    )
    test_db.add(show)
    await test_db.flush()

    s1 = Season(show_id=show.id, season_number=1, title="Season 1")
    s0 = Season(show_id=show.id, season_number=0, title="Trailers")
    test_db.add_all([s1, s0])
    await test_db.flush()

    # Ep 1 English & Hindi
    ep1_en = Episode(
        season_id=s1.id, episode_number=1, title="Hello World",
        duration_seconds=300, content_group="cg-1", language="en",
        thumbnail_url="/storage/artwork/thumb.jpg", status="published"
    )
    ep1_hi = Episode(
        season_id=s1.id, episode_number=2, title="नमस्ते दुनिया",
        duration_seconds=300, content_group="cg-1", language="hi",
        thumbnail_url="/storage/artwork/thumb.jpg", status="published"
    )
    # Trailer
    t1 = Episode(
        season_id=s0.id, episode_number=1, title="Official Trailer",
        duration_seconds=60, content_group="cg-trailer-1", language="en",
        thumbnail_url="/storage/artwork/thumb_t.jpg", status="published"
    )
    test_db.add_all([ep1_en, ep1_hi, t1])
    await test_db.commit()

    # Trigger publish
    res = await publish_catalog(test_db, triggered_by="admin@test.com")
    assert res["success"] is True
    catalog = res["published_catalog"]

    # Verify Season 0 trailers separated
    show_entry = catalog["sections"][0]["shows"][0]
    assert len(show_entry["trailers"]) == 1
    assert show_entry["trailers"][0]["content_group"] == "cg-trailer-1"

    # Verify content_group collapsed into single episode with 2 languages
    season_1 = show_entry["seasons"][0]
    assert len(season_1["episodes"]) == 1
    collapsed_ep = season_1["episodes"][0]
    assert collapsed_ep["content_group"] == "cg-1"
    assert "en" in collapsed_ep["available_languages"]
    assert "hi" in collapsed_ep["available_languages"]
    assert len(collapsed_ep["variants"]) == 2
""")

# 3. test_rbac.py
write_file("tests/test_rbac.py", """
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_editor_cannot_publish():
    # Editor role attempts to trigger publish -> 403 Forbidden
    res = client.post("/admin/catalog/publish", headers={"X-User-Role": "editor"})
    assert res.status_code == 403
    assert "Admin privileges required" in res.text

def test_admin_can_trigger_publish():
    # Admin role is authorized
    res = client.post("/admin/catalog/publish", headers={"X-User-Role": "admin"})
    # Either 200 (Success) or 400 (Blocked by validation issues from seed data), but NOT 403!
    assert res.status_code in [200, 400]
""")

# 4. test_search.py
write_file("tests/test_search.py", """
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_composed_search_filtering():
    # Search with combined query params
    res = client.get("/catalog/search?q=Moti&language=hi")
    assert res.status_code == 200
    data = res.json()
    assert "results" in data
    assert "total" in data
""")

print("All test suites written successfully.")
