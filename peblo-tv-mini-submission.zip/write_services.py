﻿import os
from pathlib import Path

def write_file(rel_path, content):
    full_path = Path("backend") / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {full_path}")

# 1. Validation Engine
write_file("app/services/validation_engine.py", """
from typing import List, Dict
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.models.models import Show, Season, Episode
from app.schemas.schemas import ValidationReport, ValidationIssue

async def generate_validation_report(db: AsyncSession) -> ValidationReport:
    \"\"\"
    Inspects all shows, seasons, and episodes to discover anything blocking publication.
    Gives non-technical editors actionable descriptions on how to fix each issue.
    \"\"\"
    result = await db.execute(
        select(Show)
        .options(selectinload(Show.seasons).selectinload(Season.episodes))
        .order_by(Show.title)
    )
    shows = result.scalars().all()

    issues_by_show: Dict[str, List[ValidationIssue]] = {}
    general_issues: List[ValidationIssue] = []
    total_blockers = 0
    total_warnings = 0
    published_shows_count = 0
    published_episodes_count = 0

    content_group_lang_tracker: Dict[tuple, List[str]] = {}

    for show in shows:
        show_issues: List[ValidationIssue] = []
        is_show_published = (show.status == "published")
        if is_show_published:
            published_shows_count += 1

        # Check 1: Published show must have a section
        if is_show_published and not show.section:
            show_issues.append(ValidationIssue(
                entity_type="show",
                entity_id=show.id,
                entity_title=show.title,
                severity="BLOCKER",
                field="section",
                message="Published show is missing a Section assignment.",
                action_required="Assign a valid Section (e.g. 'Top Picks', 'Animated Stories') in the Show edit form."
            ))
            total_blockers += 1

        # Check 2: Published show must have a poster artwork
        if is_show_published and not show.poster_url:
            show_issues.append(ValidationIssue(
                entity_type="show",
                entity_id=show.id,
                entity_title=show.title,
                severity="BLOCKER",
                field="poster_url",
                message="Published show is missing a 2:3 Poster artwork.",
                action_required="Upload a 2:3 portrait poster (~600x900px, <200KB) in the Show edit form."
            ))
            total_blockers += 1

        # Check 3: Published show must have a banner artwork
        if is_show_published and not show.banner_url:
            show_issues.append(ValidationIssue(
                entity_type="show",
                entity_id=show.id,
                entity_title=show.title,
                severity="BLOCKER",
                field="banner_url",
                message="Published show is missing a 16:9 Banner artwork.",
                action_required="Upload a 16:9 banner (~1280x720px, <200KB) in the Show edit form."
            ))
            total_blockers += 1

        # Check Seasons & Episodes
        for season in show.seasons:
            for ep in season.episodes:
                is_ep_published = (ep.status == "published")
                if is_ep_published and is_show_published:
                    published_episodes_count += 1

                # Check unique (content_group, language)
                key = (ep.content_group, ep.language)
                if key in content_group_lang_tracker:
                    content_group_lang_tracker[key].append(ep.id)
                    show_issues.append(ValidationIssue(
                        entity_type="episode",
                        entity_id=ep.id,
                        entity_title=f"{ep.title} (Ep {ep.episode_number})",
                        severity="BLOCKER",
                        field="content_group",
                        message=f"Duplicate language '{ep.language}' found for content_group '{ep.content_group}'.",
                        action_required="Each content_group can have only ONE episode per language. Change the content group or language."
                    ))
                    total_blockers += 1
                else:
                    content_group_lang_tracker[key] = [ep.id]

                # Check 4: Published episode must have duration > 0
                if is_ep_published and (ep.duration_seconds is None or ep.duration_seconds <= 0):
                    show_issues.append(ValidationIssue(
                        entity_type="episode",
                        entity_id=ep.id,
                        entity_title=f"{ep.title} (S{season.season_number}E{ep.episode_number})",
                        severity="BLOCKER",
                        field="duration_seconds",
                        message="Published episode duration must be greater than 0 seconds.",
                        action_required="Enter a valid duration (in seconds) in the Episode edit modal."
                    ))
                    total_blockers += 1

                # Check 5: Published episode must have thumbnail artwork
                if is_ep_published and not ep.thumbnail_url:
                    show_issues.append(ValidationIssue(
                        entity_type="episode",
                        entity_id=ep.id,
                        entity_title=f"{ep.title} (S{season.season_number}E{ep.episode_number})",
                        severity="BLOCKER",
                        field="thumbnail_url",
                        message="Published episode is missing a 16:9 thumbnail artwork.",
                        action_required="Upload a 16:9 thumbnail image (~640x360px, <200KB) for this episode."
                    ))
                    total_blockers += 1

        if show_issues:
            issues_by_show[show.title] = show_issues

    is_publishable = (total_blockers == 0) and (published_shows_count > 0)
    if published_shows_count == 0:
        general_issues.append(ValidationIssue(
            entity_type="system",
            entity_id="catalog",
            entity_title="Catalogue",
            severity="BLOCKER",
            field="status",
            message="No published shows found in the database.",
            action_required="Set at least one show status to 'published' to build a catalogue."
        ))
        total_blockers += 1
        is_publishable = False

    return ValidationReport(
        is_publishable=is_publishable,
        total_blockers=total_blockers,
        total_warnings=total_warnings,
        published_shows_count=published_shows_count,
        published_episodes_count=published_episodes_count,
        issues_by_show=issues_by_show,
        general_issues=general_issues
    )
""")

# 2. Catalog Publisher Service
write_file("app/services/catalog_publisher.py", """
import json
import uuid
from datetime import datetime
from typing import Dict, List, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.models.models import Show, Season, Episode, PublishRun
from app.services.storage import get_storage_provider
from app.services.validation_engine import generate_validation_report
from app.schemas.schemas import PublishedCatalog

CATALOG_DESTINATION_PATH = "catalog/catalogue.json"

async def publish_catalog(db: AsyncSession, triggered_by: str) -> Dict[str, Any]:
    \"\"\"
    Builds and atomically writes catalogue.json:
    - Verifies validation blockers first.
    - Only includes published shows and episodes.
    - Collapses episodes sharing content_group into a single entry with available_languages.
    - Separates Season 0 trailers from normal seasons.
    - Groups deterministically by section.
    - Atomically writes to storage.
    - Records publish run history.
    \"\"\"
    run_id = f"run-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6]}"
    storage = get_storage_provider()

    # Step 1: Pre-publish validation check
    val_report = await generate_validation_report(db)
    if not val_report.is_publishable:
        # Record blocked run
        publish_run = PublishRun(
            run_id=run_id,
            triggered_by=triggered_by,
            status="BLOCKED",
            error_message=f"Publication blocked by {val_report.total_blockers} unresolved blocker issues.",
            validation_snapshot=val_report.model_dump_json()
        )
        db.add(publish_run)
        await db.commit()
        return {
            "success": False,
            "status": "BLOCKED",
            "run_id": run_id,
            "message": f"Cannot publish: {val_report.total_blockers} blocking issues found.",
            "report": val_report
        }

    # Step 2: Fetch all published shows, seasons, and episodes
    result = await db.execute(
        select(Show)
        .where(Show.status == "published")
        .options(selectinload(Show.seasons).selectinload(Season.episodes))
        .order_by(Show.section, Show.title)
    )
    published_shows = result.scalars().all()

    sections_map: Dict[str, List[Dict[str, Any]]] = {}
    featured_shows: List[Dict[str, Any]] = []
    total_episodes_published = 0

    for show in published_shows:
        section_name = show.section or "Other Stories"
        if section_name not in sections_map:
            sections_map[section_name] = []

        catalog_seasons: List[Dict[str, Any]] = []
        catalog_trailers: List[Dict[str, Any]] = []
        show_episode_count = 0

        for season in sorted(show.seasons, key=lambda s: s.season_number):
            # Is this Season 0 (Trailer)?
            is_season_trailer = (season.season_number == 0)

            # Group published episodes by content_group
            grouped_episodes: Dict[str, List[Episode]] = {}
            for ep in sorted(season.episodes, key=lambda e: e.episode_number):
                if ep.status == "published":
                    cg = ep.content_group
                    if cg not in grouped_episodes:
                        grouped_episodes[cg] = []
                    grouped_episodes[cg].append(ep)

            if is_season_trailer:
                for cg, ep_list in grouped_episodes.items():
                    # Pick english or first available as default
                    default_ep = next((e for e in ep_list if e.language == "en"), ep_list[0])
                    avail_langs = [e.language for e in ep_list]
                    catalog_trailers.append({
                        "episode_number": default_ep.episode_number,
                        "content_group": cg,
                        "title": default_ep.title,
                        "synopsis": default_ep.synopsis,
                        "duration_seconds": default_ep.duration_seconds,
                        "video_url": default_ep.video_url,
                        "thumbnail_url": default_ep.thumbnail_url,
                        "available_languages": avail_langs
                    })
            else:
                collapsed_season_episodes = []
                for cg, ep_list in grouped_episodes.items():
                    default_ep = next((e for e in ep_list if e.language == "en"), ep_list[0])
                    avail_langs = [e.language for e in ep_list]
                    variants_dict = {}
                    for e in ep_list:
                        variants_dict[e.language] = {
                            "language": e.language,
                            "title": e.title,
                            "synopsis": e.synopsis,
                            "video_url": e.video_url,
                            "thumbnail_url": e.thumbnail_url,
                            "duration_seconds": e.duration_seconds
                        }

                    collapsed_season_episodes.append({
                        "episode_number": default_ep.episode_number,
                        "content_group": cg,
                        "default_title": default_ep.title,
                        "default_synopsis": default_ep.synopsis,
                        "duration_seconds": default_ep.duration_seconds,
                        "thumbnail_url": default_ep.thumbnail_url,
                        "available_languages": avail_langs,
                        "variants": variants_dict
                    })
                    show_episode_count += 1
                    total_episodes_published += 1

                if collapsed_season_episodes:
                    catalog_seasons.append({
                        "season_number": season.season_number,
                        "title": season.title or f"Season {season.season_number}",
                        "episodes": collapsed_season_episodes
                    })

        show_item = {
            "id": show.id,
            "title": show.title,
            "synopsis": show.synopsis,
            "section": section_name,
            "category": show.category,
            "target_age_group": show.target_age_group,
            "is_featured": show.is_featured,
            "poster_url": show.poster_url,
            "banner_url": show.banner_url,
            "seasons": catalog_seasons,
            "trailers": catalog_trailers,
            "total_episodes": show_episode_count
        }

        sections_map[section_name].append(show_item)
        if show.is_featured:
            featured_shows.append(show_item)

    # Order sections deterministically
    sorted_sections = [
        {"name": sec_name, "shows": shows_in_sec}
        for sec_name, shows_in_sec in sorted(sections_map.items(), key=lambda x: x[0])
    ]

    published_catalog_payload = {
        "catalog_version": run_id,
        "published_at": datetime.utcnow().isoformat() + "Z",
        "published_by": triggered_by,
        "total_shows": len(published_shows),
        "total_episodes": total_episodes_published,
        "sections": sorted_sections,
        "featured_shows": featured_shows
    }

    catalog_json_str = json.dumps(published_catalog_payload, indent=2, ensure_ascii=False)
    catalog_bytes = catalog_json_str.encode("utf-8")

    # Step 3: Atomic write to storage
    saved_path = await storage.atomic_write(catalog_bytes, CATALOG_DESTINATION_PATH)

    # Step 4: Record successful publish run
    publish_run = PublishRun(
        run_id=run_id,
        triggered_by=triggered_by,
        status="SUCCESS",
        shows_count=len(published_shows),
        episodes_count=total_episodes_published,
        sections_count=len(sorted_sections),
        catalogue_size_bytes=len(catalog_bytes),
        catalogue_path=saved_path
    )
    db.add(publish_run)
    await db.commit()

    return {
        "success": True,
        "status": "SUCCESS",
        "run_id": run_id,
        "catalogue_path": saved_path,
        "shows_count": len(published_shows),
        "episodes_count": total_episodes_published,
        "sections_count": len(sorted_sections),
        "catalogue_size_bytes": len(catalog_bytes),
        "published_catalog": published_catalog_payload
    }
""")

# 3. Seed Loader Service
write_file("app/services/seed_loader.py", """
import json
from pathlib import Path
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.models import Show, Season, Episode

SEED_FILE = Path(__file__).parent.parent / "data" / "seed_shows.json"

async def load_seed_data(db: AsyncSession, force_reload: bool = False):
    \"\"\"
    Seeds the database with seed_shows.json if not already populated.
    \"\"\"
    result = await db.execute(select(Show))
    existing_shows = result.scalars().all()
    if existing_shows and not force_reload:
        return {"message": "Database already contains data. Seed skipped."}

    if not SEED_FILE.exists():
        return {"error": f"Seed file {SEED_FILE} not found."}

    with open(SEED_FILE, "r", encoding="utf-8") as f:
        shows_data = json.load(f)

    for s_data in shows_data:
        show = Show(
            id=s_data.get("id"),
            title=s_data["title"],
            synopsis=s_data.get("synopsis"),
            section=s_data.get("section"),
            category=s_data.get("category"),
            target_age_group=s_data.get("target_age_group", "4-8"),
            is_featured=s_data.get("is_featured", False),
            status=s_data.get("status", "draft"),
            poster_url=s_data.get("poster_url"),
            banner_url=s_data.get("banner_url")
        )
        db.add(show)
        await db.flush()

        for season_data in s_data.get("seasons", []):
            season = Season(
                show_id=show.id,
                season_number=season_data.get("season_number", 1),
                title=season_data.get("title")
            )
            db.add(season)
            await db.flush()

            for ep_data in season_data.get("episodes", []):
                ep = Episode(
                    season_id=season.id,
                    episode_number=ep_data.get("episode_number", 1),
                    title=ep_data["title"],
                    synopsis=ep_data.get("synopsis"),
                    duration_seconds=ep_data.get("duration_seconds", 0),
                    content_group=ep_data["content_group"],
                    language=ep_data.get("language", "en"),
                    video_url=ep_data.get("video_url"),
                    thumbnail_url=ep_data.get("thumbnail_url"),
                    status=ep_data.get("status", "draft")
                )
                db.add(ep)

    await db.commit()
    return {"message": f"Successfully loaded {len(shows_data)} shows into database."}
""")

print("Validation engine, catalog publisher, and seed loader written.")
