﻿import os
from pathlib import Path

def write_file(rel_path, content):
    full_path = Path("backend") / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {full_path}")

# 1. Schemas
write_file("app/schemas/schemas.py", """
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, HttpUrl

# Artwork
class ArtworkValidationResult(BaseModel):
    is_valid: bool
    artwork_type: str
    width: int
    height: int
    aspect_ratio: float
    file_size_bytes: int
    file_size_kb: float
    errors: List[str] = []
    warnings: List[str] = []

class ArtworkResponse(BaseModel):
    id: str
    artwork_type: str
    file_name: str
    file_url: str
    file_size_bytes: int
    width: int
    height: int
    aspect_ratio: float
    content_type: str
    created_at: datetime

# Episodes
class EpisodeBase(BaseModel):
    episode_number: int = Field(..., ge=1)
    title: str = Field(..., min_length=1)
    synopsis: Optional[str] = None
    duration_seconds: int = Field(..., ge=0)
    content_group: str = Field(..., min_length=1)
    language: str = Field(..., min_length=2, max_length=10)
    video_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    status: str = "draft"

class EpisodeCreate(EpisodeBase):
    pass

class EpisodeUpdate(BaseModel):
    episode_number: Optional[int] = None
    title: Optional[str] = None
    synopsis: Optional[str] = None
    duration_seconds: Optional[int] = None
    content_group: Optional[str] = None
    language: Optional[str] = None
    video_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    status: Optional[str] = None

class EpisodeResponse(EpisodeBase):
    id: str
    season_id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# Seasons
class SeasonBase(BaseModel):
    season_number: int = Field(..., ge=0) # 0 is trailer
    title: Optional[str] = None

class SeasonCreate(SeasonBase):
    pass

class SeasonResponse(SeasonBase):
    id: str
    show_id: str
    created_at: datetime
    episodes: List[EpisodeResponse] = []

    class Config:
        from_attributes = True

# Shows
class ShowBase(BaseModel):
    title: str = Field(..., min_length=1)
    synopsis: Optional[str] = None
    section: Optional[str] = None
    category: Optional[str] = None
    target_age_group: Optional[str] = "4-8"
    is_featured: bool = False
    status: str = "draft"
    poster_url: Optional[str] = None
    banner_url: Optional[str] = None

class ShowCreate(ShowBase):
    pass

class ShowUpdate(BaseModel):
    title: Optional[str] = None
    synopsis: Optional[str] = None
    section: Optional[str] = None
    category: Optional[str] = None
    target_age_group: Optional[str] = None
    is_featured: Optional[bool] = None
    status: Optional[str] = None
    poster_url: Optional[str] = None
    banner_url: Optional[str] = None

class ShowResponse(ShowBase):
    id: str
    created_at: datetime
    updated_at: datetime
    seasons: List[SeasonResponse] = []

    class Config:
        from_attributes = True

# Validation Report
class ValidationIssue(BaseModel):
    entity_type: str # "show" or "episode"
    entity_id: str
    entity_title: str
    severity: str # "BLOCKER" or "WARNING"
    field: str
    message: str
    action_required: str

class ValidationReport(BaseModel):
    is_publishable: bool
    total_blockers: int
    total_warnings: int
    published_shows_count: int
    published_episodes_count: int
    issues_by_show: Dict[str, List[ValidationIssue]] = {}
    general_issues: List[ValidationIssue] = []

# Published Catalog Schema
class CatalogLanguageVariant(BaseModel):
    language: str
    title: str
    synopsis: Optional[str]
    video_url: Optional[str]
    thumbnail_url: Optional[str]
    duration_seconds: int

class CatalogEpisode(BaseModel):
    episode_number: int
    content_group: str
    default_title: str
    default_synopsis: Optional[str]
    duration_seconds: int
    thumbnail_url: Optional[str]
    available_languages: List[str]
    variants: Dict[str, CatalogLanguageVariant]

class CatalogSeason(BaseModel):
    season_number: int
    title: Optional[str]
    episodes: List[CatalogEpisode]

class CatalogTrailer(BaseModel):
    episode_number: int
    content_group: str
    title: str
    synopsis: Optional[str]
    duration_seconds: int
    video_url: Optional[str]
    thumbnail_url: Optional[str]
    available_languages: List[str]

class CatalogShow(BaseModel):
    id: str
    title: str
    synopsis: Optional[str]
    section: str
    category: Optional[str]
    target_age_group: Optional[str]
    is_featured: bool
    poster_url: Optional[str]
    banner_url: Optional[str]
    seasons: List[CatalogSeason]
    trailers: List[CatalogTrailer] = [] # Separated Season 0 trailers
    total_episodes: int

class CatalogSection(BaseModel):
    name: str
    shows: List[CatalogShow]

class PublishedCatalog(BaseModel):
    catalog_version: str
    published_at: str
    published_by: str
    total_shows: int
    total_episodes: int
    sections: List[CatalogSection]
    featured_shows: List[CatalogShow]

class PublishRunResponse(BaseModel):
    run_id: str
    triggered_by: str
    status: str
    shows_count: int
    episodes_count: int
    sections_count: int
    catalogue_path: Optional[str]
    error_message: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True
""")

# 2. Artwork Validator Service
write_file("app/services/artwork_validator.py", """
import io
import json
from pathlib import Path
from typing import Tuple, List
from PIL import Image
from app.schemas.schemas import ArtworkValidationResult

# Load reference configuration
REF_FILE = Path(__file__).parent.parent / "data" / "reference.json"
if REF_FILE.exists():
    with open(REF_FILE, "r", encoding="utf-8") as f:
        REFERENCE_DATA = json.load(f)
else:
    REFERENCE_DATA = {}

ARTWORK_SPECS = REFERENCE_DATA.get("artwork_specs", {
    "poster": {"ratio_float": 2/3, "ratio_tolerance": 0.05, "max_size_bytes": 204800, "min_width": 400, "min_height": 600, "aspect_ratio": "2:3"},
    "banner": {"ratio_float": 16/9, "ratio_tolerance": 0.05, "max_size_bytes": 204800, "min_width": 960, "min_height": 540, "aspect_ratio": "16:9"},
    "thumbnail": {"ratio_float": 16/9, "ratio_tolerance": 0.05, "max_size_bytes": 204800, "min_width": 320, "min_height": 180, "aspect_ratio": "16:9"}
})

def validate_artwork_image(file_bytes: bytes, artwork_type: str) -> ArtworkValidationResult:
    \"\"\"
    Strictly validates artwork image against the specifications in reference.json:
    - 200 KB ceiling
    - Aspect ratio tolerances
    - Minimum dimension floors
    - Returns human-friendly, actionable error messages for non-technical editors.
    \"\"\"
    errors: List[str] = []
    warnings: List[str] = []
    file_size_bytes = len(file_bytes)
    file_size_kb = round(file_size_bytes / 1024, 1)

    spec = ARTWORK_SPECS.get(artwork_type)
    if not spec:
        return ArtworkValidationResult(
            is_valid=False,
            artwork_type=artwork_type,
            width=0,
            height=0,
            aspect_ratio=0.0,
            file_size_bytes=file_size_bytes,
            file_size_kb=file_size_kb,
            errors=[f"Unknown artwork slot type '{artwork_type}'. Valid types are: poster, banner, thumbnail."]
        )

    # 1. Enforce 200 KB ceiling
    max_bytes = spec.get("max_size_bytes", 204800)
    if file_size_bytes > max_bytes:
        errors.append(
            f"File size ({file_size_kb} KB) exceeds the maximum allowed limit of 200 KB. "
            f"Please compress your image before uploading."
        )

    # 2. Inspect image dimensions using Pillow
    try:
        image = Image.open(io.BytesIO(file_bytes))
        width, height = image.size
        calculated_ratio = width / height if height > 0 else 0
    except Exception as e:
        return ArtworkValidationResult(
            is_valid=False,
            artwork_type=artwork_type,
            width=0,
            height=0,
            aspect_ratio=0.0,
            file_size_bytes=file_size_bytes,
            file_size_kb=file_size_kb,
            errors=[f"Corrupt or invalid image file. Please upload a valid JPG or PNG image. ({str(e)})"]
        )

    # 3. Enforce minimum dimensions
    min_w = spec.get("min_width", 100)
    min_h = spec.get("min_height", 100)
    if width < min_w or height < min_h:
        errors.append(
            f"Resolution is too low ({width}x{height}px). "
            f"For {artwork_type}, the minimum required resolution is {min_w}x{min_h}px."
        )

    # 4. Enforce aspect ratio with tolerance
    target_ratio = spec.get("ratio_float", 1.0)
    tolerance = spec.get("ratio_tolerance", 0.05)
    expected_ratio_str = spec.get("aspect_ratio", "specified ratio")

    ratio_diff = abs(calculated_ratio - target_ratio)
    if ratio_diff > tolerance:
        errors.append(
            f"Invalid aspect ratio ({calculated_ratio:.2f}). "
            f"{artwork_type.capitalize()} artwork must be {expected_ratio_str} "
            f"(target ratio ~{target_ratio:.2f}, got {width}x{height}px). "
            f"Please crop the image to {expected_ratio_str} before uploading."
        )

    is_valid = len(errors) == 0
    return ArtworkValidationResult(
        is_valid=is_valid,
        artwork_type=artwork_type,
        width=width,
        height=height,
        aspect_ratio=round(calculated_ratio, 3),
        file_size_bytes=file_size_bytes,
        file_size_kb=file_size_kb,
        errors=errors,
        warnings=warnings
    )
""")

print("Schemas and Artwork Validator written.")
