﻿import os
from pathlib import Path

def write_file(rel_path, content):
    full_path = Path("backend") / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {full_path}")

# 1. API Dependencies (Role & Auth)
write_file("app/api/deps.py", """
from typing import Optional
from fastapi import Depends, HTTPException, status, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.security import verify_token

security = HTTPBearer(auto_error=False)

class CurrentUser:
    def __init__(self, username: str, role: str):
        self.username = username
        self.role = role

async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    x_user_role: Optional[str] = Header(None, alias="X-User-Role")
) -> CurrentUser:
    \"\"\"
    Extracts current user from Bearer JWT token or X-User-Role development header.
    \"\"\"
    # 1. Check Bearer Token
    if credentials:
        payload = verify_token(credentials.credentials)
        if payload:
            return CurrentUser(
                username=payload.get("sub", "anonymous"),
                role=payload.get("role", "editor")
            )

    # 2. Check dev role header for seamless CMS switching
    if x_user_role:
        role = x_user_role.lower()
        if role in ["admin", "editor"]:
            return CurrentUser(username=f"{role}@mypeblo.com", role=role)

    # Default fallback for testing/dev: editor
    return CurrentUser(username="editor@mypeblo.com", role="editor")

async def require_editor(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
    if user.role not in ["editor", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Editor or Admin role required to perform this action."
        )
    return user

async def require_admin(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
    if user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin privileges required to perform this action (e.g. publishing catalogue)."
        )
    return user
""")

# 2. Endpoints: auth.py
write_file("app/api/endpoints/auth.py", """
from fastapi import APIRouter, HTTPException, Query
from app.core.security import create_access_token

router = APIRouter()

@router.post("/token")
async def get_token(role: str = Query("admin", regex="^(admin|editor)$")):
    \"\"\"Quick role-based JWT token generator for testing and CMS UI.\"\"\"
    username = f"{role}@mypeblo.com"
    token = create_access_token(subject=username, role=role)
    return {
        "access_token": token,
        "token_type": "bearer",
        "role": role,
        "username": username
    }
""")

# 3. Endpoints: shows.py
write_file("app/api/endpoints/shows.py", """
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, func
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.api.deps import require_editor, CurrentUser
from app.models.models import Show, Season, Episode
from app.schemas.schemas import ShowCreate, ShowUpdate, ShowResponse

router = APIRouter()

@router.get("/", response_model=List[ShowResponse])
async def list_shows(
    db: AsyncSession = Depends(get_db),
    section: Optional[str] = None,
    status_filter: Optional[str] = Query(None, alias="status"),
    category: Optional[str] = None,
    q: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
):
    query = select(Show).options(
        selectinload(Show.seasons).selectinload(Season.episodes)
    )
    if section:
        query = query.where(Show.section == section)
    if status_filter:
        query = query.where(Show.status == status_filter)
    if category:
        query = query.where(Show.category == category)
    if q:
        query = query.where(or_(
            Show.title.ilike(f"%{q}%"),
            Show.synopsis.ilike(f"%{q}%")
        ))

    query = query.order_by(Show.updated_at.desc()).offset(offset).limit(limit)
    result = await db.execute(query)
    return result.scalars().all()

@router.get("/{show_id}", response_model=ShowResponse)
async def get_show(show_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Show)
        .where(Show.id == show_id)
        .options(selectinload(Show.seasons).selectinload(Season.episodes))
    )
    show = result.scalar_one_or_none()
    if not show:
        raise HTTPException(status_code=404, detail=f"Show '{show_id}' not found.")
    return show

@router.post("/", response_model=ShowResponse, status_code=status.HTTP_201_CREATED)
async def create_show(
    show_in: ShowCreate,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    show = Show(**show_in.model_dump())
    db.add(show)
    await db.commit()
    await db.refresh(show)
    # create default Season 1 and Season 0 (Trailers)
    s0 = Season(show_id=show.id, season_number=0, title="Trailers & Clips")
    s1 = Season(show_id=show.id, season_number=1, title="Season 1")
    db.add_all([s0, s1])
    await db.commit()
    
    result = await db.execute(
        select(Show)
        .where(Show.id == show.id)
        .options(selectinload(Show.seasons).selectinload(Season.episodes))
    )
    return result.scalar_one()

@router.put("/{show_id}", response_model=ShowResponse)
async def update_show(
    show_id: str,
    show_in: ShowUpdate,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    result = await db.execute(
        select(Show)
        .where(Show.id == show_id)
        .options(selectinload(Show.seasons).selectinload(Season.episodes))
    )
    show = result.scalar_one_or_none()
    if not show:
        raise HTTPException(status_code=404, detail=f"Show '{show_id}' not found.")

    for field, val in show_in.model_dump(exclude_unset=True).items():
        setattr(show, field, val)

    await db.commit()
    await db.refresh(show)
    return show

@router.delete("/{show_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_show(
    show_id: str,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    result = await db.execute(select(Show).where(Show.id == show_id))
    show = result.scalar_one_or_none()
    if not show:
        raise HTTPException(status_code=404, detail=f"Show '{show_id}' not found.")
    await db.delete(show)
    await db.commit()
    return None
""")

# 4. Endpoints: episodes.py & seasons.py
write_file("app/api/endpoints/episodes.py", """
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from app.core.database import get_db
from app.api.deps import require_editor, CurrentUser
from app.models.models import Episode, Season, Show
from app.schemas.schemas import EpisodeCreate, EpisodeUpdate, EpisodeResponse

router = APIRouter()

@router.post("/season/{season_id}", response_model=EpisodeResponse, status_code=status.HTTP_201_CREATED)
async def create_episode(
    season_id: str,
    ep_in: EpisodeCreate,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    # Verify season exists
    res = await db.execute(select(Season).where(Season.id == season_id))
    season = res.scalar_one_or_none()
    if not season:
        raise HTTPException(status_code=404, detail=f"Season '{season_id}' not found.")

    # Enforce (content_group, language) uniqueness
    res_dup = await db.execute(
        select(Episode).where(
            and_(
                Episode.content_group == ep_in.content_group,
                Episode.language == ep_in.language
            )
        )
    )
    if res_dup.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"An episode with content_group '{ep_in.content_group}' and language '{ep_in.language}' already exists."
        )

    episode = Episode(season_id=season_id, **ep_in.model_dump())
    db.add(episode)
    await db.commit()
    await db.refresh(episode)
    return episode

@router.put("/{episode_id}", response_model=EpisodeResponse)
async def update_episode(
    episode_id: str,
    ep_in: EpisodeUpdate,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    res = await db.execute(select(Episode).where(Episode.id == episode_id))
    ep = res.scalar_one_or_none()
    if not ep:
        raise HTTPException(status_code=404, detail=f"Episode '{episode_id}' not found.")

    data = ep_in.model_dump(exclude_unset=True)
    new_cg = data.get("content_group", ep.content_group)
    new_lang = data.get("language", ep.language)

    if new_cg != ep.content_group or new_lang != ep.language:
        res_dup = await db.execute(
            select(Episode).where(
                and_(
                    Episode.content_group == new_cg,
                    Episode.language == new_lang,
                    Episode.id != ep.id
                )
            )
        )
        if res_dup.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Conflict: (content_group='{new_cg}', language='{new_lang}') already in use by another episode."
            )

    for k, v in data.items():
        setattr(ep, k, v)

    await db.commit()
    await db.refresh(ep)
    return ep

@router.delete("/{episode_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_episode(
    episode_id: str,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    res = await db.execute(select(Episode).where(Episode.id == episode_id))
    ep = res.scalar_one_or_none()
    if not ep:
        raise HTTPException(status_code=404, detail=f"Episode '{episode_id}' not found.")
    await db.delete(ep)
    await db.commit()
    return None
""")

write_file("app/api/endpoints/seasons.py", """
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.api.deps import require_editor, CurrentUser
from app.models.models import Season, Show
from app.schemas.schemas import SeasonCreate, SeasonResponse

router = APIRouter()

@router.post("/show/{show_id}", response_model=SeasonResponse, status_code=status.HTTP_201_CREATED)
async def add_season(
    show_id: str,
    season_in: SeasonCreate,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    res = await db.execute(select(Show).where(Show.id == show_id))
    if not res.scalar_one_or_none():
        raise HTTPException(status_code=404, detail=f"Show '{show_id}' not found.")

    res_exist = await db.execute(
        select(Season).where(
            Season.show_id == show_id,
            Season.season_number == season_in.season_number
        )
    )
    if res_exist.scalar_one_or_none():
        raise HTTPException(status_code=400, detail=f"Season {season_in.season_number} already exists for this show.")

    season = Season(show_id=show_id, **season_in.model_dump())
    db.add(season)
    await db.commit()
    await db.refresh(season)
    return season
""")

# 5. Endpoints: artwork.py
write_file("app/api/endpoints/artwork.py", """
import uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.api.deps import require_editor, CurrentUser
from app.services.artwork_validator import validate_artwork_image
from app.services.storage import get_storage_provider
from app.models.models import Artwork
from app.schemas.schemas import ArtworkResponse, ArtworkValidationResult

router = APIRouter()

@router.post("/validate", response_model=ArtworkValidationResult)
async def validate_artwork(
    artwork_type: str = Form(..., regex="^(poster|banner|thumbnail)$"),
    file: UploadFile = File(...)
):
    \"\"\"Pre-validation endpoint allowing CMS editors to check dimensions/size before uploading.\"\"\"
    content = await file.read()
    return validate_artwork_image(content, artwork_type)

@router.post("/upload", response_model=ArtworkResponse, status_code=status.HTTP_201_CREATED)
async def upload_artwork(
    artwork_type: str = Form(..., regex="^(poster|banner|thumbnail)$"),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    \"\"\"
    Strictly validates and uploads artwork per reference.json specifications:
    - poster: 2:3 ratio, max 200KB
    - banner: 16:9 ratio, max 200KB
    - thumbnail: 16:9 ratio, max 200KB
    Returns actionable human-readable errors on failure.
    \"\"\"
    content = await file.read()
    validation = validate_artwork_image(content, artwork_type)

    if not validation.is_valid:
        error_details = " | ".join(validation.errors)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "message": f"Artwork validation failed for '{artwork_type}' slot.",
                "errors": validation.errors,
                "specs": {
                    "width": validation.width,
                    "height": validation.height,
                    "aspect_ratio": validation.aspect_ratio,
                    "size_kb": validation.file_size_kb
                }
            }
        )

    # Save to storage abstraction
    storage = get_storage_provider()
    ext = file.filename.split(".")[-1] if "." in file.filename else "jpg"
    safe_filename = f"{artwork_type}_{uuid.uuid4().hex[:8]}.{ext}"
    dest_path = f"artwork/{safe_filename}"

    file_url = await storage.save_file(content, dest_path, content_type=file.content_type or "image/jpeg")

    # Record in database
    artwork_record = Artwork(
        artwork_type=artwork_type,
        file_name=file.filename,
        file_url=file_url,
        file_size_bytes=validation.file_size_bytes,
        width=validation.width,
        height=validation.height,
        aspect_ratio=validation.aspect_ratio,
        content_type=file.content_type or "image/jpeg",
        uploaded_by=user.username
    )
    db.add(artwork_record)
    await db.commit()
    await db.refresh(artwork_record)

    return artwork_record
""")

# 6. Endpoints: catalog.py, validation.py, health.py
write_file("app/api/endpoints/catalog.py", """
import json
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query, status, Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from app.core.database import get_db
from app.api.deps import require_admin, require_editor, CurrentUser
from app.services.catalog_publisher import publish_catalog, CATALOG_DESTINATION_PATH
from app.services.storage import get_storage_provider
from app.models.models import PublishRun
from app.schemas.schemas import PublishRunResponse

router = APIRouter()

@router.get("/", summary="Viewer Catalogue Endpoint")
async def get_catalogue(db: AsyncSession = Depends(get_db)):
    \"\"\"
    Serves the pre-published catalogue.json file directly from storage.
    Fast, atomic, and isolated from live operational DB transactions.
    \"\"\"
    storage = get_storage_provider()
    try:
        data = await storage.read_file(CATALOG_DESTINATION_PATH)
        return json.loads(data.decode("utf-8"))
    except FileNotFoundError:
        # Fallback: if not published yet, publish automatically for smooth local DX
        result = await publish_catalog(db, triggered_by="system_init")
        if result.get("success"):
            return result.get("published_catalog")
        raise HTTPException(
            status_code=404,
            detail="Catalogue not published yet. Please publish the catalogue from the Admin CMS."
        )

@router.get("/search", summary="Composed Catalogue Search")
async def search_catalogue(
    q: Optional[str] = Query(None, description="Matches show title, synopsis, or episode title"),
    category: Optional[str] = Query(None, description="Exact category filter"),
    language: Optional[str] = Query(None, description="Available language (e.g. en, hi)"),
    section: Optional[str] = Query(None, description="Section filter"),
    db: AsyncSession = Depends(get_db)
):
    \"\"\"
    Full composed search matching show titles, episode titles, and categories.
    All filter parameters compose together smoothly.
    \"\"\"
    storage = get_storage_provider()
    try:
        data = await storage.read_file(CATALOG_DESTINATION_PATH)
        catalog = json.loads(data.decode("utf-8"))
    except FileNotFoundError:
        return {"results": [], "total": 0, "query": {"q": q, "category": category, "language": language, "section": section}}

    matched_shows = []
    q_lower = q.lower().strip() if q else ""

    # Flatten all shows from all sections
    seen_show_ids = set()
    all_shows = []
    for sec in catalog.get("sections", []):
        for s in sec.get("shows", []):
            if s["id"] not in seen_show_ids:
                seen_show_ids.add(s["id"])
                all_shows.append(s)

    for show in all_shows:
        # 1. Section filter
        if section and show.get("section") != section:
            continue

        # 2. Category filter
        if category and show.get("category") != category:
            continue

        # 3. Language filter (check if any episode offers this language)
        if language:
            has_lang = False
            for season in show.get("seasons", []):
                for ep in season.get("episodes", []):
                    if language in ep.get("available_languages", []):
                        has_lang = True
                        break
                if has_lang:
                    break
            if not has_lang:
                continue

        # 4. Text query `q` filter (matches show title, synopsis, or any episode title)
        if q_lower:
            match_title = q_lower in show.get("title", "").lower()
            match_synopsis = q_lower in (show.get("synopsis") or "").lower()
            match_category = q_lower in (show.get("category") or "").lower()
            match_episode = False
            for season in show.get("seasons", []):
                for ep in season.get("episodes", []):
                    if q_lower in ep.get("default_title", "").lower():
                        match_episode = True
                        break
                    for variant in ep.get("variants", {}).values():
                        if q_lower in variant.get("title", "").lower():
                            match_episode = True
                            break
                    if match_episode:
                        break
            if not (match_title or match_synopsis or match_category or match_episode):
                continue

        matched_shows.append(show)

    return {
        "results": matched_shows,
        "total": len(matched_shows),
        "filters_applied": {
            "q": q,
            "category": category,
            "language": language,
            "section": section
        }
    }

@router.post("/publish", summary="Trigger Catalogue Publish (Admin Only)")
async def trigger_publish(
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_admin)
):
    \"\"\"
    Enforced Admin-only endpoint: validates content and atomically publishes catalogue.json.
    Returns 403 Forbidden for editor role.
    \"\"\"
    result = await publish_catalog(db, triggered_by=user.username)
    if not result.get("success"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=result
        )
    return result

@router.get("/runs", response_model=List[PublishRunResponse])
async def list_publish_runs(
    limit: int = 20,
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    \"\"\"Returns audit history of publish runs.\"\"\"
    res = await db.execute(
        select(PublishRun).order_by(desc(PublishRun.created_at)).limit(limit)
    )
    return res.scalars().all()
""")

write_file("app/api/endpoints/validation.py", """
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.api.deps import require_editor, CurrentUser
from app.services.validation_engine import generate_validation_report
from app.schemas.schemas import ValidationReport

router = APIRouter()

@router.get("/report", response_model=ValidationReport)
async def get_validation_report(
    db: AsyncSession = Depends(get_db),
    user: CurrentUser = Depends(require_editor)
):
    \"\"\"
    Surfaces all current publish blockers grouped cleanly for non-technical editors.
    \"\"\"
    return await generate_validation_report(db)
""")

write_file("app/api/endpoints/health.py", """
import time
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from app.core.database import get_db
from app.services.storage import get_storage_provider
from app.services.catalog_publisher import CATALOG_DESTINATION_PATH

router = APIRouter()

@router.get("/")
async def health_check(db: AsyncSession = Depends(get_db)):
    \"\"\"
    Production health & readiness endpoint.
    Checks: Database connectivity, storage backend readiness, catalogue status.
    \"\"\"
    # 1. DB ping
    db_ok = True
    db_latency_ms = 0.0
    try:
        t0 = time.time()
        await db.execute(text("SELECT 1"))
        db_latency_ms = round((time.time() - t0) * 1000, 2)
    except Exception:
        db_ok = False

    # 2. Storage & Catalog check
    storage = get_storage_provider()
    catalog_published = await storage.file_exists(CATALOG_DESTINATION_PATH)

    overall_status = "healthy" if (db_ok and catalog_published) else "degraded"

    return {
        "status": overall_status,
        "database": {
            "connected": db_ok,
            "latency_ms": db_latency_ms
        },
        "catalogue": {
            "published": catalog_published,
            "path": CATALOG_DESTINATION_PATH
        },
        "version": "1.0.0"
    }
""")

# 7. Main Application: app/main.py
write_file("app/main.py", """
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.core.config import settings
from app.core.database import engine, Base, AsyncSessionLocal
from app.services.seed_loader import load_seed_data
from app.api.endpoints import shows, episodes, seasons, artwork, catalog, validation, auth, health

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Create tables if not exist and seed data
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as session:
        await load_seed_data(session)

    yield
    # Shutdown
    await engine.dispose()

app = FastAPI(
    title=settings.PROJECT_NAME,
    lifespan=lifespan,
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount local storage folder for artwork and catalogue file access
storage_dir = os.path.abspath(settings.LOCAL_STORAGE_DIR)
os.makedirs(storage_dir, exist_ok=True)
app.mount("/storage", StaticFiles(directory=storage_dir), name="storage")

# Include API Routers
app.include_router(health.router, prefix="/health", tags=["Health"])
app.include_router(auth.router, prefix=f"{settings.API_V1_STR}/auth", tags=["Auth"])
app.include_router(shows.router, prefix=f"{settings.API_V1_STR}/shows", tags=["Shows"])
app.include_router(seasons.router, prefix=f"{settings.API_V1_STR}/seasons", tags=["Seasons"])
app.include_router(episodes.router, prefix=f"{settings.API_V1_STR}/episodes", tags=["Episodes"])
app.include_router(artwork.router, prefix=f"{settings.API_V1_STR}/artwork", tags=["Artwork"])
app.include_router(catalog.router, prefix="/catalog", tags=["Viewer Catalog"])
app.include_router(catalog.router, prefix="/admin/catalog", tags=["Admin Catalog Publishing"])
app.include_router(validation.router, prefix="/admin/validation", tags=["Admin Validation"])

@app.get("/")
def root():
    return {
        "message": "Welcome to Peblo TV Mini Platform API",
        "docs": "/docs",
        "health": "/health",
        "catalog": "/catalog"
    }
""")

print("Backend API endpoints and main application written successfully!")
