﻿import os
from pathlib import Path

# 1. Update artwork_validator.py to always check file size ceiling first and handle corrupt image gracefully
val_code = """
import io
import json
from pathlib import Path
from typing import Tuple, List
from PIL import Image
from app.schemas.schemas import ArtworkValidationResult

REF_FILE = Path(__file__).parent.parent / "data" / "reference.json"
if REF_FILE.exists():
    with open(REF_FILE, "r", encoding="utf-8") as f:
        REFERENCE_DATA = json.load(f)
else:
    REFERENCE_DATA = {}

ARTWORK_SPECS = REFERENCE_DATA.get("artwork_specs", {
    "poster": {"ratio_float": 2/3, "ratio_tolerance": 0.05, "max_size_bytes": 204800, "min_width": 400, "min_height": 600, "aspect_ratio": "2:3"},
    "banner": {"ratio_float": 16/9, "ratio_tolerance": 0.05, "max_size_bytes": 204800, "min_width": 960, "min_height": 540, "aspect_ratio": "16:9"},
    "thumbnail": {"ratio_float": 16/9, "ratio_tolerance": 0.05, "max_size_bytes": 204800, "min_width": 320, "min_height": 180, "aspect_ratio": "16:9"}
})

def validate_artwork_image(file_bytes: bytes, artwork_type: str) -> ArtworkValidationResult:
    \"\"\"
    Strictly validates artwork image against the specifications in reference.json:
    - 200 KB ceiling (204,800 bytes)
    - Aspect ratio tolerances
    - Minimum dimension floors
    - Returns human-friendly, actionable error messages for non-technical editors.
    \"\"\"
    errors: List[str] = []
    warnings: List[str] = []
    file_size_bytes = len(file_bytes)
    file_size_kb = round(file_size_bytes / 1024, 1)

    spec = ARTWORK_SPECS.get(artwork_type)
    if not spec:
        return ArtworkValidationResult(
            is_valid=False,
            artwork_type=artwork_type,
            width=0,
            height=0,
            aspect_ratio=0.0,
            file_size_bytes=file_size_bytes,
            file_size_kb=file_size_kb,
            errors=[f"Unknown artwork slot type '{artwork_type}'. Valid types are: poster, banner, thumbnail."]
        )

    # 1. Enforce 200 KB ceiling (204,800 bytes)
    max_bytes = spec.get("max_size_bytes", 204800)
    if file_size_bytes > max_bytes:
        errors.append(
            f"File size ({file_size_kb} KB) exceeds the maximum allowed limit of 200 KB. "
            f"Please compress your image before uploading."
        )

    # 2. Inspect image dimensions using Pillow
    try:
        image = Image.open(io.BytesIO(file_bytes))
        width, height = image.size
        calculated_ratio = width / height if height > 0 else 0
    except Exception as e:
        errors.append(f"Corrupt or invalid image file format. ({str(e)})")
        return ArtworkValidationResult(
            is_valid=False,
            artwork_type=artwork_type,
            width=0,
            height=0,
            aspect_ratio=0.0,
            file_size_bytes=file_size_bytes,
            file_size_kb=file_size_kb,
            errors=errors
        )

    # 3. Enforce minimum dimensions
    min_w = spec.get("min_width", 100)
    min_h = spec.get("min_height", 100)
    if width < min_w or height < min_h:
        errors.append(
            f"Resolution is too low ({width}x{height}px). "
            f"For {artwork_type}, the minimum required resolution is {min_w}x{min_h}px."
        )

    # 4. Enforce aspect ratio with tolerance
    target_ratio = spec.get("ratio_float", 1.0)
    tolerance = spec.get("ratio_tolerance", 0.05)
    expected_ratio_str = spec.get("aspect_ratio", "specified ratio")

    ratio_diff = abs(calculated_ratio - target_ratio)
    if ratio_diff > tolerance:
        errors.append(
            f"Invalid aspect ratio ({calculated_ratio:.2f}). "
            f"{artwork_type.capitalize()} artwork must be {expected_ratio_str} "
            f"(target ratio ~{target_ratio:.2f}, got {width}x{height}px). "
            f"Please crop the image to {expected_ratio_str} before uploading."
        )

    is_valid = len(errors) == 0
    return ArtworkValidationResult(
        is_valid=is_valid,
        artwork_type=artwork_type,
        width=width,
        height=height,
        aspect_ratio=round(calculated_ratio, 3),
        file_size_bytes=file_size_bytes,
        file_size_kb=file_size_kb,
        errors=errors,
        warnings=warnings
    )
"""
Path("backend/app/services/artwork_validator.py").write_text(val_code.strip() + "\n", encoding="utf-8")

# 2. Update test_artwork.py to generate valid oversized image using Pillow uncompressed
test_art_code = """
import io
import pytest
from PIL import Image
from app.services.artwork_validator import validate_artwork_image

def create_image_bytes(width, height, format="JPEG", quality=85):
    img = Image.new("RGB", (width, height), color=(50, 100, 150))
    buf = io.BytesIO()
    img.save(buf, format=format, quality=quality)
    return buf.getvalue()

def test_valid_poster_artwork():
    # 2:3 ratio (~600x900)
    data = create_image_bytes(600, 900)
    res = validate_artwork_image(data, "poster")
    assert res.is_valid is True
    assert len(res.errors) == 0
    assert res.width == 600
    assert res.height == 900

def test_valid_banner_artwork():
    # 16:9 ratio (~1280x720)
    data = create_image_bytes(1280, 720)
    res = validate_artwork_image(data, "banner")
    assert res.is_valid is True
    assert len(res.errors) == 0

def test_valid_thumbnail_artwork():
    # 16:9 ratio (~640x360)
    data = create_image_bytes(640, 360)
    res = validate_artwork_image(data, "thumbnail")
    assert res.is_valid is True

def test_reject_wrong_aspect_ratio():
    # 1:1 square for poster (expected 2:3)
    data = create_image_bytes(600, 600)
    res = validate_artwork_image(data, "poster")
    assert res.is_valid is False
    assert any("Invalid aspect ratio" in err for err in res.errors)

def test_reject_too_small_resolution():
    # 100x100 is below minimum dimension floor
    data = create_image_bytes(100, 100)
    res = validate_artwork_image(data, "thumbnail")
    assert res.is_valid is False
    assert any("Resolution is too low" in err for err in res.errors)

def test_reject_oversized_file():
    # Generate image exceeding 200KB limit
    img = Image.new("RGB", (3000, 2000), color=(100, 150, 200))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    oversized_data = buf.getvalue()
    assert len(oversized_data) > 204800
    res = validate_artwork_image(oversized_data, "banner")
    assert res.is_valid is False
    assert any("exceeds the maximum allowed limit of 200 KB" in err for err in res.errors)
"""
Path("backend/tests/test_artwork.py").write_text(test_art_code.strip() + "\n", encoding="utf-8")

# 3. Update test_rbac.py and test_search.py to use `with TestClient(app) as client:`
test_rbac_code = """
import pytest
from fastapi.testclient import TestClient
from app.main import app

def test_editor_cannot_publish():
    with TestClient(app) as client:
        res = client.post("/admin/catalog/publish", headers={"X-User-Role": "editor"})
        assert res.status_code == 403
        assert "Admin privileges required" in res.text

def test_admin_can_trigger_publish():
    with TestClient(app) as client:
        res = client.post("/admin/catalog/publish", headers={"X-User-Role": "admin"})
        # 200 (Success) or 400 (Blocked with validation report), but NOT 403 Forbidden!
        assert res.status_code in [200, 400]
"""
Path("backend/tests/test_rbac.py").write_text(test_rbac_code.strip() + "\n", encoding="utf-8")

test_search_code = """
import pytest
from fastapi.testclient import TestClient
from app.main import app

def test_composed_search_filtering():
    with TestClient(app) as client:
        res = client.get("/catalog/search?q=Moti&language=hi")
        assert res.status_code == 200
        data = res.json()
        assert "results" in data
        assert "total" in data
"""
Path("backend/tests/test_search.py").write_text(test_search_code.strip() + "\n", encoding="utf-8")

# 4. Update FastAPIDeprecationWarning in endpoint query parameters
art_ep_path = Path("backend/app/api/endpoints/artwork.py")
art_ep_text = art_ep_path.read_text(encoding="utf-8").replace('regex="^(poster|banner|thumbnail)$"', 'pattern="^(poster|banner|thumbnail)$"')
art_ep_path.write_text(art_ep_text, encoding="utf-8")

auth_ep_path = Path("backend/app/api/endpoints/auth.py")
auth_ep_text = auth_ep_path.read_text(encoding="utf-8").replace('regex="^(admin|editor)$"', 'pattern="^(admin|editor)$"')
auth_ep_path.write_text(auth_ep_text, encoding="utf-8")

print("Updated tests and validation services.")
