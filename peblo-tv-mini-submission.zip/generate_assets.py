﻿import os
from PIL import Image, ImageDraw, ImageFont

assets_dir = r"backend/app/data/assets"
storage_artwork_dir = r"backend/storage/artwork"
os.makedirs(assets_dir, exist_ok=True)
os.makedirs(storage_artwork_dir, exist_ok=True)

def create_img(filename, width, height, color, text, target_dir, quality=85):
    img = Image.new("RGB", (width, height), color=color)
    draw = ImageDraw.Draw(img)
    
    # Draw simple grid pattern
    for i in range(0, width, 40):
        draw.line([(i, 0), (i, height)], fill=(255, 255, 255, 30), width=1)
    for j in range(0, height, 40):
        draw.line([(0, j), (width, j)], fill=(255, 255, 255, 30), width=1)
        
    draw.text((20, 20), text, fill=(255, 255, 255))
    draw.text((20, 50), f"{width}x{height}", fill=(255, 255, 255))
    
    out_path = os.path.join(target_dir, filename)
    if filename.endswith(".png"):
        img.save(out_path, format="PNG")
    else:
        img.save(out_path, format="JPEG", quality=quality)
    print(f"Created {out_path} ({os.path.getsize(out_path)/1024:.1f} KB)")

# Test Assets per spec:
# 1. poster_good: 2:3 ratio (~600x900, <200KB)
create_img("poster_good.jpg", 600, 900, (41, 128, 185), "POSTER GOOD (2:3)", assets_dir)
# 2. poster_wrong_ratio: 1:1 square (600x600, invalid ratio)
create_img("poster_wrong_ratio.jpg", 600, 600, (231, 76, 60), "POSTER WRONG RATIO (1:1)", assets_dir)
# 3. banner_good: 16:9 ratio (~1280x720, <200KB)
create_img("banner_good.jpg", 1280, 720, (39, 174, 96), "BANNER GOOD (16:9)", assets_dir)
# 4. banner_too_big: Massive resolution uncompressed PNG exceeding 200KB limit
img_huge = Image.new("RGB", (3840, 2160), color=(142, 68, 173))
draw_huge = ImageDraw.Draw(img_huge)
import random
# Add noise to inflate file size over 200KB
for _ in range(5000):
    x = random.randint(0, 3800)
    y = random.randint(0, 2100)
    draw_huge.rectangle([x, y, x+30, y+30], fill=(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
draw_huge.text((100, 100), "BANNER TOO BIG (>200KB)", fill=(255, 255, 255))
huge_path = os.path.join(assets_dir, "banner_too_big.png")
img_huge.save(huge_path, format="PNG")
print(f"Created {huge_path} ({os.path.getsize(huge_path)/1024:.1f} KB)")

# 5. thumb_good: 16:9 ratio (~640x360, <200KB)
create_img("thumb_good.jpg", 640, 360, (243, 156, 18), "THUMB GOOD (16:9)", assets_dir)
# 6. thumb_tiny: 100x100 (below min dimension & wrong ratio)
create_img("thumb_tiny.jpg", 100, 100, (192, 57, 43), "THUMB TINY (100x100)", assets_dir)

# Seed show artworks for local rendering
show_configs = [
    ("moti", "Moti's Many Lives", (230, 126, 34)),
    ("science", "Peblo Science Lab", (52, 152, 219)),
    ("tenali", "Tenali Raman", (155, 89, 182)),
    ("gita", "Gita for Kids", (241, 196, 15)),
    ("bedtime", "Bedtime Stars", (44, 62, 80)),
    ("rhyme", "Rhyme Time", (26, 188, 156)),
    ("jungle", "Jungle Safari", (46, 204, 113)),
    ("panchatantra", "Panchatantra", (211, 84, 0))
]

for key, title, col in show_configs:
    create_img(f"{key}_poster.jpg", 600, 900, col, f"SHOW: {title}\nPoster (2:3)", storage_artwork_dir)
    create_img(f"{key}_banner.jpg", 1280, 720, col, f"PEBLO FEATURED: {title}\nBanner (16:9)", storage_artwork_dir)
    create_img(f"{key}_thumb_1.jpg", 640, 360, col, f"{title} - Ep 1", storage_artwork_dir)
    create_img(f"{key}_thumb_2.jpg", 640, 360, col, f"{title} - Ep 2", storage_artwork_dir)
    create_img(f"{key}_thumb_3.jpg", 640, 360, col, f"{title} - Ep 3", storage_artwork_dir)
    create_img(f"{key}_thumb_t1.jpg", 640, 360, col, f"{title} - Trailer 1", storage_artwork_dir)

print("Artwork and sample assets generated successfully!")
