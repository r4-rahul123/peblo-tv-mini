﻿import os
from pathlib import Path
from PIL import Image
import random

# Generate a real valid PNG with noise that is > 250KB
img = Image.new("RGB", (1920, 1080))
pixels = img.load()
for i in range(0, 1920, 4):
    for j in range(0, 1080, 4):
        pixels[i, j] = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
oversized_path = Path("backend/app/data/assets/banner_too_big.png")
img.save(oversized_path, format="PNG")
print(f"Generated {oversized_path}: {oversized_path.stat().st_size} bytes")

test_art_code = """
import io
import pytest
from pathlib import Path
from PIL import Image
from app.services.artwork_validator import validate_artwork_image

def create_image_bytes(width, height, format="JPEG", quality=85):
    img = Image.new("RGB", (width, height), color=(50, 100, 150))
    buf = io.BytesIO()
    img.save(buf, format=format, quality=quality)
    return buf.getvalue()

def test_valid_poster_artwork():
    # 2:3 ratio (~600x900)
    data = create_image_bytes(600, 900)
    res = validate_artwork_image(data, "poster")
    assert res.is_valid is True
    assert len(res.errors) == 0
    assert res.width == 600
    assert res.height == 900

def test_valid_banner_artwork():
    # 16:9 ratio (~1280x720)
    data = create_image_bytes(1280, 720)
    res = validate_artwork_image(data, "banner")
    assert res.is_valid is True
    assert len(res.errors) == 0

def test_valid_thumbnail_artwork():
    # 16:9 ratio (~640x360)
    data = create_image_bytes(640, 360)
    res = validate_artwork_image(data, "thumbnail")
    assert res.is_valid is True

def test_reject_wrong_aspect_ratio():
    # 1:1 square for poster (expected 2:3)
    data = create_image_bytes(600, 600)
    res = validate_artwork_image(data, "poster")
    assert res.is_valid is False
    assert any("Invalid aspect ratio" in err for err in res.errors)

def test_reject_too_small_resolution():
    # 100x100 is below minimum dimension floor
    data = create_image_bytes(100, 100)
    res = validate_artwork_image(data, "thumbnail")
    assert res.is_valid is False
    assert any("Resolution is too low" in err for err in res.errors)

def test_reject_oversized_file():
    # Read genuine oversized PNG
    oversized_file = Path("backend/app/data/assets/banner_too_big.png")
    oversized_data = oversized_file.read_bytes()
    assert len(oversized_data) > 204800
    res = validate_artwork_image(oversized_data, "banner")
    assert res.is_valid is False
    assert any("exceeds the maximum allowed limit of 200 KB" in err for err in res.errors)
"""
Path("backend/tests/test_artwork.py").write_text(test_art_code.strip() + "\n", encoding="utf-8")
print("Updated test_artwork.py")
